package seoo.module2.isa;

public class Y
{

    public int add(int i, int j)
    {
        return i + j;
    }


}
