package seoo.module2.uses;

public class Baggage
{
    private double weight;

    public double getWeight()
    {
        return weight;
    }

    public Baggage(double weight)
    {
        this.weight = weight;
    }

}
