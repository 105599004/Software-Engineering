package seoo.module2.knows;

public class Bitmap
{

    public void draw(int x, int y)
    {
        System.out.println("drawing image: (" + x + "," + y + ")");
    }

}
