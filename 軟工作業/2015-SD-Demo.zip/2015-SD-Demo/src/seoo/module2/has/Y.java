package seoo.module2.has;

public class Y
{

    public int add(int i, int j)
    {
        return i + j;
    }


}
