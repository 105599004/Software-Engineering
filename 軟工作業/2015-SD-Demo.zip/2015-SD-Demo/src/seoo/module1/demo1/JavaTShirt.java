package seoo.module1.demo1;

public class JavaTShirt
{
    private String color;

    private String size;

    public JavaTShirt(String color, String size)
    {
        super();
        this.color = color;
        this.size = size;
    }

    public String getColor()
    {
        return color;
    }

    public String getSize()
    {
        return size;
    }
}
