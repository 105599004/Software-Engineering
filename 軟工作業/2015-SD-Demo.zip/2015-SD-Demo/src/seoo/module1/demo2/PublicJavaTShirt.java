package seoo.module1.demo2;

public class PublicJavaTShirt
{
    public String color;

    public String size;

}
