package edu.nccu.cs.se;

/** ATM.java created on 2011/9/22
 * 
 * This file is a part of OOP Design Pattern Lab. materials.
 *
 * @author Pin-Ying Tu
 * @version 1.1
 */
public class ATM
{

    public static void main(String[] args)
    {
        ATMModel model = new ATMModel();
        model.initialize();
        ATMTextUI ui = new ATMTextUI(model);
        ui.show();
    }

}
