package edu.nccu.cs.se;

/** Account.java created on 2011/9/22
 * 
 * This file is a part of OOP Design Pattern Lab. materials.
 *
 * @author Pin-Ying Tu
 * @version 1.0
 */
public class Account
{

    private Bank bank;

    private String id;

    private String password;

    private double balance;

    public Account(Bank bank, String id, String password, double initBalance)
    {
        this.bank = bank;
        this.id = id;
        this.password = password;
        balance = initBalance;
    }

    public String getID()
    {
        return id;
    }

    public double getBalance()
    {
        return balance;
    }

    public String getBankName()
    {
        return bank.getName();
    }

    public boolean checkPassword(String password)
    {
        return password.equals(password);
    }

    public boolean withdraw(double amount)
    {
        if (amount > 0 && balance >= amount)
        {
            balance -= amount;
            return true;
        }
        return false;
    }

    public boolean deposit(double amount)
    {
        if (amount > 0)
        {
            balance += amount;
            return true;
        }
        return false;
    }
}
